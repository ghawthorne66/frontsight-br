
export default [
 

  {
    path: "/",
    text: "home",
  },
  
  {
   path: "/services",
   text: "services",
  
 },

//  {
//   path: "/about",
//   text: "about",
  
//  },
 
 {
  path: "/blog",
  text: "blog",
  
 },

  {
    path: "/contact",
    text: "contact",
    
  },
  // {
  //   path: "/pricing",
  //   text: "pricing",
    
  // },
  // {
  //   path: "/prices",
  //   text: "prices",
    
  // },
  {
   path: "/appointment",
   text: "Get a Demo",
  
 },
 
  
]
