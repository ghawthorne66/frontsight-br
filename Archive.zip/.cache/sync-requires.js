const { hot } = require("react-hot-loader/root")

// prefer default export if available
const preferDefault = m => m && m.default || m


exports.components = {
  "component---cache-dev-404-page-js": hot(preferDefault(require("/Users/nisum/Documents/projects/FL-Work/ready-to-deliver/frontsight/.cache/dev-404-page.js"))),
  "component---src-pages-404-js": hot(preferDefault(require("/Users/nisum/Documents/projects/FL-Work/ready-to-deliver/frontsight/src/pages/404.js"))),
  "component---src-pages-about-js": hot(preferDefault(require("/Users/nisum/Documents/projects/FL-Work/ready-to-deliver/frontsight/src/pages/about.js"))),
  "component---src-pages-appointment-jsx": hot(preferDefault(require("/Users/nisum/Documents/projects/FL-Work/ready-to-deliver/frontsight/src/pages/appointment.jsx"))),
  "component---src-pages-blog-js": hot(preferDefault(require("/Users/nisum/Documents/projects/FL-Work/ready-to-deliver/frontsight/src/pages/blog.js"))),
  "component---src-pages-contact-js": hot(preferDefault(require("/Users/nisum/Documents/projects/FL-Work/ready-to-deliver/frontsight/src/pages/contact.js"))),
  "component---src-pages-index-js": hot(preferDefault(require("/Users/nisum/Documents/projects/FL-Work/ready-to-deliver/frontsight/src/pages/index.js"))),
  "component---src-pages-prices-jsx": hot(preferDefault(require("/Users/nisum/Documents/projects/FL-Work/ready-to-deliver/frontsight/src/pages/prices.jsx"))),
  "component---src-pages-pricing-jsx": hot(preferDefault(require("/Users/nisum/Documents/projects/FL-Work/ready-to-deliver/frontsight/src/pages/pricing.jsx"))),
  "component---src-pages-services-js": hot(preferDefault(require("/Users/nisum/Documents/projects/FL-Work/ready-to-deliver/frontsight/src/pages/services.js"))),
  "component---src-templates-blog-list-template-js": hot(preferDefault(require("/Users/nisum/Documents/projects/FL-Work/ready-to-deliver/frontsight/src/templates/blog-list-template.js"))),
  "component---src-templates-blog-template-js": hot(preferDefault(require("/Users/nisum/Documents/projects/FL-Work/ready-to-deliver/frontsight/src/templates/blog-template.js"))),
  "component---src-templates-services-template-js": hot(preferDefault(require("/Users/nisum/Documents/projects/FL-Work/ready-to-deliver/frontsight/src/templates/services-template.js")))
}

